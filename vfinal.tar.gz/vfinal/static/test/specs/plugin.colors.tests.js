describe('Plugin.colors', () => {
  describe('auto', jasmine.fixture.specs('plugin.colors'));
});
