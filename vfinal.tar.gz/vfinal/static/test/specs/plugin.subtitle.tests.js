describe('plugin.subtitle', function() {
  describe('auto', jasmine.fixture.specs('plugin.subtitle'));
});
