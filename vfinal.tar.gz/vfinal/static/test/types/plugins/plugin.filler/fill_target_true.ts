import type { ChartDataset } from '../../../../src/types.js';

const dataset: ChartDataset = {
  data: [],
  fill: true,
};
